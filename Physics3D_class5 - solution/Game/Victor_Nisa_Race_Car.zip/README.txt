-----------------
-RACING CAR GAME-
-----------------
-by  Victor Nisa-
-----------------


Controls
--------
Arrow keys
Up to accelerate
Down to go backwards (make sure to pull the brake first)
Left and Right to steer left and right

WASD keys to move camera

Spacebar to pull the brake and stop your car

F1 to enable debug display



Goal
----

Your goal is to drive the Canyonero up the hill on your left.
Take as much time as you wish, but if you flip your car over, you lose.
Once you have reached the top, apporach the magical blue cube
that will recognize your victory. Happy driving!



Known issues
------------
-Sometimes (on my pc only as far as I know) an error popup appears at the
 start of the game. It does not affect gameplay at all.

-Sometimes the game lags on launch, making the game laggy.
 Restarting the game should fix that issue.
 (tested a bunch, it only happened like 10% of the time)

-If your car flips over, you need to manually restart the game, which is a pain.



Credits
-------
Mostly Everything - CITM's handouts (citm.upc.edu)

The Rest - Victor Nisa (github.com/VictorNisa)

Repository link - https://github.com/VictorNisa/Racing_Game





